from langchain_community.embeddings.xinference import XinferenceEmbeddings

__all__ = ["XinferenceEmbeddings"]
