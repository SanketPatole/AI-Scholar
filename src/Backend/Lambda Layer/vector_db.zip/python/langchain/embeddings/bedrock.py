from langchain_community.embeddings.bedrock import BedrockEmbeddings

__all__ = ["BedrockEmbeddings"]
