from langchain_community.embeddings.fake import (
    DeterministicFakeEmbedding,
    FakeEmbeddings,
)

__all__ = ["FakeEmbeddings", "DeterministicFakeEmbedding"]
