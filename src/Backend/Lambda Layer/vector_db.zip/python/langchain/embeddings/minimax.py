from langchain_community.embeddings.minimax import (
    MiniMaxEmbeddings,
)

__all__ = ["MiniMaxEmbeddings"]
