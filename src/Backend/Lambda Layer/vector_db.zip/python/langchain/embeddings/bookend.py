from langchain_community.embeddings.bookend import (
    BookendEmbeddings,
)

__all__ = ["BookendEmbeddings"]
