from langchain_community.embeddings.llm_rails import LLMRailsEmbeddings

__all__ = ["LLMRailsEmbeddings"]
