from langchain_community.embeddings.javelin_ai_gateway import (
    JavelinAIGatewayEmbeddings,
)

__all__ = ["JavelinAIGatewayEmbeddings"]
