from langchain_community.embeddings.mlflow import MlflowEmbeddings

__all__ = ["MlflowEmbeddings"]
