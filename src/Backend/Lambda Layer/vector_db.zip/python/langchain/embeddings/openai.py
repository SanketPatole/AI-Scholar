from langchain_community.embeddings.openai import (
    OpenAIEmbeddings,
)

__all__ = [
    "OpenAIEmbeddings",
]
