from langchain_community.embeddings.dashscope import (
    DashScopeEmbeddings,
)

__all__ = ["DashScopeEmbeddings"]
