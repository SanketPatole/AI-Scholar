from langchain_community.embeddings.sagemaker_endpoint import (
    EmbeddingsContentHandler,
    SagemakerEndpointEmbeddings,
)

__all__ = ["EmbeddingsContentHandler", "SagemakerEndpointEmbeddings"]
