from langchain_community.embeddings.gradient_ai import GradientEmbeddings

__all__ = ["GradientEmbeddings"]
