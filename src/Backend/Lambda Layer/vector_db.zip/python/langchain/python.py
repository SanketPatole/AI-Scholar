"""For backwards compatibility."""
from langchain_community.utilities.python import PythonREPL

__all__ = ["PythonREPL"]
