"""DEPRECATED: Kept for backwards compatibility."""
from langchain_community.utilities import Requests, RequestsWrapper, TextRequestsWrapper

__all__ = [
    "Requests",
    "RequestsWrapper",
    "TextRequestsWrapper",
]
