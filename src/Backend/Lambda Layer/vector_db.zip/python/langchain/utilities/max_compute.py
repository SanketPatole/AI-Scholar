from langchain_community.utilities.max_compute import MaxComputeAPIWrapper

__all__ = ["MaxComputeAPIWrapper"]
