from langchain_community.utilities.powerbi import (
    PowerBIDataset,
)

__all__ = [
    "PowerBIDataset",
]
