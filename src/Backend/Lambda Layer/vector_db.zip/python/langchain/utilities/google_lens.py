from langchain_community.utilities.google_lens import GoogleLensAPIWrapper

__all__ = ["GoogleLensAPIWrapper"]
