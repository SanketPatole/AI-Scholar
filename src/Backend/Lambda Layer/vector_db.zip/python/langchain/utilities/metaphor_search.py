from langchain_community.utilities.metaphor_search import (
    MetaphorSearchAPIWrapper,
)

__all__ = ["MetaphorSearchAPIWrapper"]
