from langchain_community.utilities.google_trends import GoogleTrendsAPIWrapper

__all__ = ["GoogleTrendsAPIWrapper"]
