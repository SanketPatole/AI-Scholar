from langchain_community.utilities.wikipedia import (
    WikipediaAPIWrapper,
)

__all__ = ["WikipediaAPIWrapper"]
