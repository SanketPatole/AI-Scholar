from langchain_community.utilities.duckduckgo_search import DuckDuckGoSearchAPIWrapper

__all__ = ["DuckDuckGoSearchAPIWrapper"]
