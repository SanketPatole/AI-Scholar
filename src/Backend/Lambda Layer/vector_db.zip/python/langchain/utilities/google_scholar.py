from langchain_community.utilities.google_scholar import GoogleScholarAPIWrapper

__all__ = ["GoogleScholarAPIWrapper"]
