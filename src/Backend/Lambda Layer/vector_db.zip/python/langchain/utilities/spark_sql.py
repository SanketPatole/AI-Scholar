from langchain_community.utilities.spark_sql import SparkSQL

__all__ = ["SparkSQL"]
