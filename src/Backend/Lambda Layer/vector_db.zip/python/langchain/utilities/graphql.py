from langchain_community.utilities.graphql import GraphQLAPIWrapper

__all__ = ["GraphQLAPIWrapper"]
