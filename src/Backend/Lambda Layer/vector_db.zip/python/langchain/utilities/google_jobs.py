from langchain_community.utilities.google_jobs import GoogleJobsAPIWrapper

__all__ = ["GoogleJobsAPIWrapper"]
