from langchain_community.chat_models.vertexai import (
    ChatVertexAI,
)

__all__ = [
    "ChatVertexAI",
]
