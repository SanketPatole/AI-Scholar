from langchain_core.utils.pydantic import get_pydantic_major_version

__all__ = ["get_pydantic_major_version"]
