from langchain_community.chat_message_histories.dynamodb import (
    DynamoDBChatMessageHistory,
)

__all__ = ["DynamoDBChatMessageHistory"]
