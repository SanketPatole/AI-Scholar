"""Google Scholar API Toolkit."""

from langchain_community.tools.google_scholar.tool import GoogleScholarQueryRun

__all__ = ["GoogleScholarQueryRun"]
