from langchain_community.document_transformers.doctran_text_qa import (
    DoctranQATransformer,
)

__all__ = ["DoctranQATransformer"]
