from langchain_community.document_transformers.doctran_text_extract import (
    DoctranPropertyExtractor,
)

__all__ = ["DoctranPropertyExtractor"]
