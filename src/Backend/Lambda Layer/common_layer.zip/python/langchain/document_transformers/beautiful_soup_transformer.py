from langchain_community.document_transformers.beautiful_soup_transformer import (
    BeautifulSoupTransformer,
)

__all__ = ["BeautifulSoupTransformer"]
