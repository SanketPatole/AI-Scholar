from langchain_community.vectorstores.tair import Tair

__all__ = ["Tair"]
