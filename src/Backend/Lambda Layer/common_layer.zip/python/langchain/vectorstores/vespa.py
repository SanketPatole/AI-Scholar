from langchain_community.vectorstores.vespa import VespaStore

__all__ = ["VespaStore"]
