from langchain_community.vectorstores.astradb import (
    AstraDB,
)

__all__ = [
    "AstraDB",
]
