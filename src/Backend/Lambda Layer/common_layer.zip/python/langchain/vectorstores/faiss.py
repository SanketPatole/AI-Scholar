from langchain_community.vectorstores.faiss import (
    FAISS,
)

__all__ = ["FAISS"]
