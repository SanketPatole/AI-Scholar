from langchain_community.vectorstores.deeplake import DeepLake

__all__ = ["DeepLake"]
