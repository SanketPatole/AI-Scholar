from langchain_community.vectorstores.dingo import Dingo

__all__ = ["Dingo"]
