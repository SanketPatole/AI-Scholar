from langchain_community.vectorstores.supabase import SupabaseVectorStore

__all__ = ["SupabaseVectorStore"]
