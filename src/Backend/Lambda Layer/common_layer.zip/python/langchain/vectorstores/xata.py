from langchain_community.vectorstores.xata import XataVectorStore

__all__ = ["XataVectorStore"]
